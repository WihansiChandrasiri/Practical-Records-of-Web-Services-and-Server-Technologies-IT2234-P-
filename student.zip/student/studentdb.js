let students = 
[
			  {regno:'2021ICT01', name:'James',gender:'Male',age:21, course:'IT'},
			  {regno:'2021ICT02', name:'Ravi',gender:'Male',age:22, course:'AMC'},
			  {regno:'2021ICT03', name:'Gayatri',gender:'Female',age:21, course:'IT'},
              {regno:'2021ICT04', name:'Vimala',gender:'Female',age:21, course:'AMC'},
              {regno:'2021ICT05', name:'Arjun',gender:'Male',age:21, course:'IT'}
];

module.exports=students